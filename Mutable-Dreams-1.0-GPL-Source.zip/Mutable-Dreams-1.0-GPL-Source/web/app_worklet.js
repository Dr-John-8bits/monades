// SPDX-License-Identifier: MIT OR GPL-3.0-only
// Firmware commands only. All sound and all pixels come from the C/C++ firmware.
globalThis.fm1App={message(f,m){const e=f.ex;if(m.cmd==='patch-export'||m.cmd==='patch-import'){if(!f.patchRequests)f.patchRequests=[];if(f.patchRequests.length<8)f.patchRequests.push(m);else f.port.postMessage({type:'patch-result',id:m.id,error:'Too many pending requests.'});return;}if(m.cmd==='command')e.dream_command(m.c,m.t,m.v);if(m.cmd==='page')e.dream_page(m.v);if(m.cmd==='track')e.dream_track(m.v);},afterRender(f){
 const m=f.patchRequests?.shift();if(!m)return;const e=f.ex,n=e.dream_patch_size();
 try{
  if(m.cmd==='patch-export'){
   const bytes=Array.from(new Uint8Array(f.mem.buffer,e.dream_patch_data(),n));
   f.port.postMessage({type:'patch-result',id:m.id,bytes});
  }else{
   if(e.dream_value(16,0))throw Error('Stop playback before importing a patch.');
   if(!Array.isArray(m.bytes)||m.bytes.length!==n||m.bytes.some(v=>!Number.isInteger(v)||v<0||v>255))throw Error('This patch file is not valid.');
   new Uint8Array(f.mem.buffer,e.dream_patch_buffer(),n).set(m.bytes);
   if(!e.dream_patch_apply(n))throw Error('This patch contains invalid or unsupported values.');
   f.port.postMessage({type:'patch-result',id:m.id,loaded:true});
  }
 }catch(err){f.port.postMessage({type:'patch-result',id:m.id,error:err.message});}
},process(f){if(!f.dreamFrames)f.dreamFrames=0;if(++f.dreamFrames%16===0){let e=f.ex;f.port.postMessage({type:'state',octave:e.dream_value(107,0),help:e.dream_value(108,0),lastNote:e.dream_value(109,e.dream_value(101,0)),events:e.dream_value(110,e.dream_value(101,0)),motion:e.dream_value(103,0),biome:e.dream_value(20,0),edited:e.dream_value(102,0),tones:Array.from({length:6},(_,i)=>e.dream_value(45,i)),page:e.dream_value(100,0),track:e.dream_value(101,0),playing:e.dream_value(16,0),knobs:Array.from({length:4},(_,k)=>e.dream_knob(e.dream_value(100,0),e.dream_value(101,0),k)),tempo:e.dream_value(15,0),locked:e.dream_value(17,0),freeze:e.dream_value(21,0),raw:Array.from({length:4},(_,k)=>e.dream_raw_knob(e.dream_value(100,0),e.dream_value(101,0),k)),muted:Array.from({length:6},(_,i)=>e.dream_value(12,i)),models:Array.from({length:6},(_,i)=>e.dream_value(0,i)),macro:Array.from({length:4},(_,i)=>e.dream_value(14,i))});}}};
