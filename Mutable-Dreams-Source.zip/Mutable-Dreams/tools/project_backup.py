#!/usr/bin/env python3
"""Read-only export of live Mutable Dreams state and its saved flash object.
The saved object may belong to a previous firmware. No implicit conversion.
Requires a stopped transport and bench protocol 2 (Mutable Dreams 0.3.1 and newer).
"""
import argparse,hashlib,json,struct,zlib
from pathlib import Path
from hardware_bench import Device

def main():
 p=argparse.ArgumentParser();p.add_argument('--port');p.add_argument('directory');a=p.parse_args()
 d=Device(a.port);out=Path(a.directory);out.mkdir(parents=True,exist_ok=True)
 try:
  state=d.status()
  if state['playing']:raise SystemExit('Stop playback before the snapshot.')
  live=d.patch();assert live==d.patch(),'Live patch changed during snapshot'
  (out/'Mutable-Dreams-Live.raw').write_bytes(live)
  (out/'Mutable-Dreams-Live.mdp').write_bytes(struct.pack('<IIII',0x50444d44,1,len(live),zlib.crc32(live))+live)
  def saved():
   size,magic,version=struct.unpack('<III',d.call(6));assert 12<=size<=3840
   b=b''.join(d.call(5,[off&127,off>>7]) for off in range(0,size,224));assert len(b)==size
   return b,magic,version
  try:
   b,magic,version=saved();assert b==saved()[0],'Saved object changed'
   (out/'FM1-Gespeichertes-Projekt.raw').write_bytes(b)
   if magic==0x50444143:(out/'Cut-A-Dor-Gespeichertes-Projekt.cadp').write_bytes(struct.pack('<IIII',0x4a504443,1,len(b),zlib.crc32(b))+b)
   info={'bytes':len(b),'magic':hex(magic),'version':version,'sha256':hashlib.sha256(b).hexdigest(),'two_identical_reads':True}
  except RuntimeError as e:
   if str(e)!='command 6: status 3':raise
   info={'status':'no valid saved object'}
  report={'live_sha256':hashlib.sha256(live).hexdigest(),'live_bytes':len(live),'saved':info,'device_status':state,'read_only':True}
  (out/'Projekt-Sicherungspruefung.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
 finally:d.close()
if __name__=='__main__':main()
