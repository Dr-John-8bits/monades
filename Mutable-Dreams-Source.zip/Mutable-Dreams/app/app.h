/* SPDX-License-Identifier: MIT */
#pragma once
#include "plat.h"
#define APP_NAME "MUTABLE DREAMS"
#define APP_SPLASH_RGB RGB(216,160,163)
#define APP_BLOCK 128u
#define APP_CANVAS_PX (240u*40u)
#define APP_HOST_EXPECT
#define APP_WEB
#define APP_SPLASH
void app_splash(void);
#define APP_OVERLOAD
#define APP_SYSEX
int app_sysex(const uint8_t *,uint32_t);
enum { OBJ_PATCH,OBJ_PANEL,OBJ_PREFS,OBJ_NOBJ };
#define APP_STORE_MAP {0xFC000u,0xDC000u,0xDA000u}
void app_init(void);
void app_render(int32_t *,uint32_t,uint32_t);
void app_panic(void);
void app_ui_init(void);
void app_frame(void);
void app_input_only(void);
void app_say(const char *,const char *);
void app_overload(void);
int app_expect(const char *,int *);
